#include <func.h>

int tcp_init(const char* ,int );
int tcp_accept(int);
int tcp_connect(const char*,int);
