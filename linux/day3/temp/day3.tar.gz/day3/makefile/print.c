#include <stdio.h>

void print()
{
	printf("I am print\n");
	return;
}
