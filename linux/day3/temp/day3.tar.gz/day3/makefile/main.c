#include <stdio.h>

void print();
int sub(int,int);
int main()
{
	printf("I am main %d\n",sub(5,4));
	print();
	print();
	return 0;
}
