#include <stdio.h>

int main()
{
#ifdef DEBUG
	printf("this is debug information\n");
#endif
}
