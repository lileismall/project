#include <stdio.h>

int main()
{
	printf("%*s%s\n",10,"","hello");
	return 0;
}
