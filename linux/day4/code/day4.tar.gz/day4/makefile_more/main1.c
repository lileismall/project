#include <stdio.h>

int main()
{
	printf("I am testcase 2\n");
	return 0;
}
