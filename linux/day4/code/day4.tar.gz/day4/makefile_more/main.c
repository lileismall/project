#include <stdio.h>

int main()
{
	printf("I am testcase 1\n");
	return 0;
}
