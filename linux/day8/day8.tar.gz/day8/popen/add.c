#include <func.h>

int main()
{
    int i,j;
    scanf("%d%d",&i,&j);
    printf("%d\n",i+j);
    return 0;
}

