#include <func.h>

int main()
{
    printf("I am print\n");
    return 0;
}

