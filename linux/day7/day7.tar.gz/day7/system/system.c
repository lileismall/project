#include <func.h>

int main()
{
    system("sleep 20");
    printf("after system\n");
    return 0;
}

