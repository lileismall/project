#include <func.h>

int main()
{
    system("./first.py");
    printf("after system\n");
    return 0;
}

