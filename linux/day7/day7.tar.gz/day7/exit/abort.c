#include <func.h>

int main()
{
    abort();
    return 0;
}

