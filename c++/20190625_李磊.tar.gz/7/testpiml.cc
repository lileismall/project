#include "pimpl.h"


using namespace std;

int main()
{
    Test test(4);
    test.print();
    return 0;
}

